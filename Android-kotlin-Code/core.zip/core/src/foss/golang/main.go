package golang

import (
	_ "cfa/native/all"
)
