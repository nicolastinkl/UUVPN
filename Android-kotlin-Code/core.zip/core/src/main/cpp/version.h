#ifndef VERSION_H_IN
#define VERSION_H_IN
 
/**
 * 当前编译core版本号
 */
 
#define GIT_VERSION __241031
#define make_Str(x) #x 
#define make_String(x) make_Str(x)

#endif
